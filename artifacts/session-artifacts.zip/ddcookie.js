const http = require('http');
const net = require('net');
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const PROXY_HOST = 'pr.oxylabs.io';
const PROXY_PORT = 7777;
const PROXY_USER = process.env.PXUSER || 'customer-mobile_d2e4fc34-cc-us-sessid-br77-sesstime-30';
const PROXY_PASS = process.env.PXPASS || '7E6Ci42a6C=8';
const AUTH = 'Basic ' + Buffer.from(PROXY_USER + ':' + PROXY_PASS).toString('base64');
const LOCAL_PORT = 8899;
const CDP_PORT = 9222;
const TARGET = 'https://www.yelp.com/login';

const relay = http.createServer((req, res) => {
  try {
    const u = new URL(req.url);
    const opts = {
      host: u.hostname,
      port: u.port || 80,
      method: req.method,
      path: u.pathname + u.search,
      headers: Object.assign({}, req.headers, { host: u.host })
    };
    const pr = http.request(opts, (presp) => {
      res.writeHead(presp.statusCode, presp.headers);
      presp.pipe(res);
    });
    pr.on('error', () => res.destroy());
    req.pipe(pr);
  } catch (e) { res.destroy(); }
});

relay.on('connect', (req, clientSocket, head) => {
  const s = net.connect(PROXY_PORT, PROXY_HOST, () => {
    s.write('CONNECT ' + req.url + ' HTTP/1.1\r\nHost: ' + req.url + '\r\nProxy-Authorization: ' + AUTH + '\r\n\r\n');
  });
  let buf = Buffer.alloc(0);
  function onData(d) {
    buf = Buffer.concat([buf, d]);
    const idx = buf.indexOf('\r\n\r\n');
    if (idx === -1) return;
    s.removeListener('data', onData);
    const headStr = buf.slice(0, idx).toString();
    const rest = buf.slice(idx + 4);
    const m = headStr.match(/^HTTP\/1\.[01]\s+(\d+)/);
    const status = m ? parseInt(m[1], 10) : 0;
    if (status !== 200) {
      try { clientSocket.end('HTTP/1.1 502 Bad Gateway\r\n\r\n'); } catch (e) {}
      s.destroy();
      return;
    }
    clientSocket.write('HTTP/1.1 200 Connection Established\r\n\r\n');
    if (rest.length) clientSocket.write(rest);
    s.pipe(clientSocket);
    clientSocket.pipe(s);
    if (head && head.length) s.write(head);
    s.on('error', () => clientSocket.destroy());
    clientSocket.on('error', () => s.destroy());
  }
  s.on('data', onData);
  s.on('error', () => { try { clientSocket.end('HTTP/1.1 502 Bad Gateway\r\n\r\n'); } catch (e) {} });
});

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function getJson(url, tries) {
  for (let i = 0; i < tries; i++) {
    try {
      const r = await fetch(url);
      return await r.json();
    } catch (e) { await sleep(500); }
  }
  return null;
}

(async () => {
  await new Promise(r => relay.listen(LOCAL_PORT, '127.0.0.1', r));

  const udd = path.join(os.tmpdir(), 'cdp-prof-' + Date.now());
  const chrome = spawn('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', [
    '--headless=new',
    '--disable-gpu',
    '--no-first-run',
    '--no-default-browser-check',
    '--disable-blink-features=AutomationControlled',
    '--window-size=1366,900',
    '--lang=en-US',
    '--user-data-dir=' + udd,
    '--proxy-server=http://127.0.0.1:' + LOCAL_PORT,
    '--remote-debugging-port=' + CDP_PORT,
    TARGET
  ], { stdio: 'ignore' });

  const ver = await getJson('http://127.0.0.1:' + CDP_PORT + '/json/version', 40);
  if (!ver) { console.log(JSON.stringify({ ok: false, err: 'cdp not ready' })); chrome.kill(); relay.close(); return; }

  const ws = new WebSocket(ver.webSocketDebuggerUrl);
  let id = 0;
  const pending = new Map();
  ws.addEventListener('message', (ev) => {
    try {
      const msg = JSON.parse(ev.data);
      if (msg.id && pending.has(msg.id)) { pending.get(msg.id)(msg); pending.delete(msg.id); }
    } catch (e) {}
  });
  await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', rej); });

  function send(method, params) {
    return new Promise((resolve) => {
      const mid = ++id;
      pending.set(mid, resolve);
      ws.send(JSON.stringify({ id: mid, method, params: params || {} }));
    });
  }

  await sleep(14000);

  const targets = await send('Target.getTargets');
  let pageInfo = null;
  if (targets && targets.result) {
    const pg = targets.result.targetInfos.find(t => t.type === 'page');
    if (pg) {
      const att = await send('Target.attachToTarget', { targetId: pg.targetId, flatten: true });
      if (att && att.result) {
        const sid = att.result.sessionId;
        const expr = "location.href + ' | ' + document.title + ' | len=' + document.documentElement.outerHTML.length";
        const u = await sendRaw(ws, 'Runtime.evaluate', { expression: expr }, sid);
        pageInfo = { url: pg.url, eval: u };
      }
    }
  }

  const cookies = await send('Storage.getCookies', {});
  const list = (cookies && cookies.result && cookies.result.cookies) ? cookies.result.cookies : [];
  const dd = list.filter(c => c.name === 'datadome').map(c => ({ value: c.value, domain: c.domain, len: c.value.length }));
  const others = list.map(c => c.name).slice(0, 20);

  console.log(JSON.stringify({ ok: true, pageInfo, datadome: dd, cookieNames: others, total: list.length }, null, 1));

  try { ws.close(); } catch (e) {}
  try { chrome.kill(); } catch (e) {}
  try { relay.close(); } catch (e) {}
  setTimeout(() => process.exit(0), 1500);
})();

async function sendRaw(ws, method, params, sessionId) {
  return new Promise((resolve) => {
    const mid = Math.floor(Math.random() * 1e9);
    const handler = (ev) => {
      try {
        const m = JSON.parse(ev.data);
        if (m.id === mid) {
          ws.removeEventListener('message', handler);
          resolve(m.result ? (m.result.result ? m.result.result.value : m.result) : null);
        }
      } catch (e) {}
    };
    ws.addEventListener('message', handler);
    ws.send(JSON.stringify({ id: mid, method, params: params || {}, sessionId }));
    setTimeout(() => resolve(null), 8000);
  });
}
