const http = require('http');
const net = require('net');
const { spawn } = require('child_process');
const os = require('os');
const path = require('path');

const PH = 'pr.oxylabs.io', PP = 7777;
const PU = process.env.PXUSER || 'customer-mobile_d2e4fc34-cc-us-sessid-tk01-sesstime-60';
const PW = process.env.PXPASS || '7E6Ci42a6C=8';
const AUTH = 'Basic ' + Buffer.from(PU + ':' + PW).toString('base64');
const LP = 8930, CP = 9250;

const relay = http.createServer((req, res) => {
  try {
    const u = new URL(req.url);
    const pr = http.request({ host: u.hostname, port: u.port || 80, method: req.method, path: u.pathname + u.search, headers: Object.assign({}, req.headers, { host: u.host }) }, r2 => { res.writeHead(r2.statusCode, r2.headers); r2.pipe(res); });
    pr.on('error', () => res.destroy()); req.pipe(pr);
  } catch (e) { res.destroy(); }
});
relay.on('connect', (req, cs, head) => {
  const s = net.connect(PP, PH, () => s.write('CONNECT ' + req.url + ' HTTP/1.1\r\nHost: ' + req.url + '\r\nProxy-Authorization: ' + AUTH + '\r\n\r\n'));
  let buf = Buffer.alloc(0);
  function onData(d) {
    buf = Buffer.concat([buf, d]);
    const i = buf.indexOf('\r\n\r\n'); if (i < 0) return;
    s.removeListener('data', onData);
    const rest = buf.slice(i + 4);
    const m = buf.slice(0, i).toString().match(/^HTTP\/1\.[01]\s+(\d+)/);
    if (!m || parseInt(m[1], 10) !== 200) { try { cs.end('HTTP/1.1 502 Bad Gateway\r\n\r\n'); } catch (e) {} s.destroy(); return; }
    cs.write('HTTP/1.1 200 Connection Established\r\n\r\n');
    if (rest.length) cs.write(rest);
    s.pipe(cs); cs.pipe(s);
    if (head && head.length) s.write(head);
    s.on('error', () => cs.destroy()); cs.on('error', () => s.destroy());
  }
  s.on('data', onData);
  s.on('error', () => { try { cs.end('HTTP/1.1 502 Bad Gateway\r\n\r\n'); } catch (e) {} });
});

const sleep = ms => new Promise(r => setTimeout(r, ms));
async function j(u, n) { for (let i = 0; i < n; i++) { try { const r = await fetch(u); return await r.json(); } catch (e) { await sleep(500); } } return null; }

(async () => {
  await new Promise(r => relay.listen(LP, '127.0.0.1', r));
  const udd = path.join(os.tmpdir(), 'cdp-tk-' + Date.now());
  const chrome = spawn('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', [
    '--no-first-run', '--no-default-browser-check', '--disable-blink-features=AutomationControlled',
    '--window-size=1100,800', '--lang=en-US', '--user-data-dir=' + udd,
    '--proxy-server=http://127.0.0.1:' + LP, '--remote-debugging-port=' + CP,
    'https://www.yelp.com/login'
  ], { stdio: 'ignore' });

  const ver = await j('http://127.0.0.1:' + CP + '/json/version', 40);
  if (!ver) { console.log('{"ok":false,"err":"cdp"}'); chrome.kill(); relay.close(); return; }
  const ws = new WebSocket(ver.webSocketDebuggerUrl);
  let id = 0; const pend = new Map();
  ws.addEventListener('message', ev => { try { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } } catch (e) {} });
  await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', rej); });
  const send = (m, p) => new Promise(resolve => { const mid = ++id; pend.set(mid, resolve); ws.send(JSON.stringify({ id: mid, method: m, params: p || {} })); });

  await sleep(9000);
  const t = await send('Target.getTargets');
  let sid = null;
  if (t && t.result) { const pg = t.result.targetInfos.find(x => x.type === 'page'); if (pg) { const a = await send('Target.attachToTarget', { targetId: pg.targetId, flatten: true }); if (a && a.result) sid = a.result.sessionId; } }
  const ev = e => new Promise(resolve => {
    const mid = Math.floor(Math.random() * 1e9);
    const h = x => { try { const m = JSON.parse(x.data); if (m.id === mid) { ws.removeEventListener('message', h); resolve(m.result && m.result.result ? m.result.result.value : null); } } catch (err) {} };
    ws.addEventListener('message', h);
    ws.send(JSON.stringify({ id: mid, method: 'Runtime.evaluate', params: { expression: e, returnByValue: true, awaitPromise: true }, sessionId: sid }));
    setTimeout(() => resolve(null), 60000);
  });
  await send('Page.enable');

  let hydrated = false;
  for (let a = 0; a < 4 && !hydrated; a++) {
    for (let k = 0; k < 14; k++) {
      await sleep(1500);
      const s = await ev(`JSON.stringify({f:!!document.getElementById('ajax-login'),l:document.documentElement.outerHTML.length,h:typeof window.hcaptcha})`);
      try { const o = JSON.parse(s); if (o && o.f && o.l > 400000 && o.h === 'object') { hydrated = true; break; } } catch (e) {}
    }
    if (!hydrated) await send('Page.navigate', { url: 'https://www.yelp.com/login/' });
  }
  console.log('HYDRATED ' + hydrated);
  if (!hydrated) { chrome.kill(); relay.close(); return; }

  const r = await ev(`(async()=>{
    try {
      var el=document.createElement('div'); el.id='tk-widget'; document.body.appendChild(el);
      var wid=window.hcaptcha.render(el,{sitekey:'6660d4df-1884-4ac6-a933-e5f3bd460946',size:'invisible'});
      var t0=Date.now();
      var res=await window.hcaptcha.execute(wid);
      return JSON.stringify({ok:true,wid:wid,ms:Date.now()-t0,tok:(res&&res.response)?res.response.length:0,keys:res?Object.keys(res):null});
    } catch(e){ return JSON.stringify({ok:false,err:String(e&&e.message||e).slice(0,200)}); }
  })()`);
  console.log('RENDER_EXEC ' + r);

  const r2 = await ev(`(async()=>{
    try {
      var wid=window.hcaptcha.render(document.getElementById('tk-widget'),{sitekey:'6660d4df-1884-4ac6-a933-e5f3bd460946',size:'invisible'});
      var out=[];
      for(var i=0;i<3;i++){ var t0=Date.now(); var res=await window.hcaptcha.execute(wid); out.push({i,ms:Date.now()-t0,len:(res&&res.response)?res.response.length:0}); }
      return JSON.stringify(out);
    } catch(e){ return JSON.stringify({ok:false,err:String(e&&e.message||e).slice(0,200)}); }
  })()`);
  console.log('MULTI ' + r2);

  try { ws.close(); } catch (e) {}
  try { chrome.kill(); } catch (e) {}
  try { relay.close(); } catch (e) {}
  setTimeout(() => process.exit(0), 1000);
})();
