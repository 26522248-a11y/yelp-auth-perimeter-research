const http = require('http');
const net = require('net');
const { spawn } = require('child_process');
const os = require('os');
const path = require('path');

const PROXY_HOST = 'pr.oxylabs.io';
const PROXY_PORT = 7777;
const PROXY_USER = process.env.PXUSER || 'customer-mobile_d2e4fc34-cc-us-sessid-insp1-sesstime-20';
const PROXY_PASS = process.env.PXPASS || '7E6Ci42a6C=8';
const AUTH = 'Basic ' + Buffer.from(PROXY_USER + ':' + PROXY_PASS).toString('base64');
const LOCAL_PORT = 8901;
const CDP_PORT = 9223;
const TARGET = process.env.TARGET || 'https://www.yelp.com/login/';

const relay = http.createServer((req, res) => {
  try {
    const u = new URL(req.url);
    const pr = http.request({ host: u.hostname, port: u.port || 80, method: req.method, path: u.pathname + u.search, headers: Object.assign({}, req.headers, { host: u.host }) }, (presp) => {
      res.writeHead(presp.statusCode, presp.headers); presp.pipe(res);
    });
    pr.on('error', () => res.destroy()); req.pipe(pr);
  } catch (e) { res.destroy(); }
});
relay.on('connect', (req, clientSocket, head) => {
  const s = net.connect(PROXY_PORT, PROXY_HOST, () => {
    s.write('CONNECT ' + req.url + ' HTTP/1.1\r\nHost: ' + req.url + '\r\nProxy-Authorization: ' + AUTH + '\r\n\r\n');
  });
  let buf = Buffer.alloc(0);
  function onData(d) {
    buf = Buffer.concat([buf, d]);
    const idx = buf.indexOf('\r\n\r\n');
    if (idx === -1) return;
    s.removeListener('data', onData);
    const rest = buf.slice(idx + 4);
    const m = buf.slice(0, idx).toString().match(/^HTTP\/1\.[01]\s+(\d+)/);
    if (!m || parseInt(m[1], 10) !== 200) { try { clientSocket.end('HTTP/1.1 502 Bad Gateway\r\n\r\n'); } catch (e) {} s.destroy(); return; }
    clientSocket.write('HTTP/1.1 200 Connection Established\r\n\r\n');
    if (rest.length) clientSocket.write(rest);
    s.pipe(clientSocket); clientSocket.pipe(s);
    if (head && head.length) s.write(head);
    s.on('error', () => clientSocket.destroy());
    clientSocket.on('error', () => s.destroy());
  }
  s.on('data', onData);
  s.on('error', () => { try { clientSocket.end('HTTP/1.1 502 Bad Gateway\r\n\r\n'); } catch (e) {} });
});

const sleep = ms => new Promise(r => setTimeout(r, ms));
async function getJson(url, tries) {
  for (let i = 0; i < tries; i++) { try { const r = await fetch(url); return await r.json(); } catch (e) { await sleep(500); } }
  return null;
}

(async () => {
  await new Promise(r => relay.listen(LOCAL_PORT, '127.0.0.1', r));
  const udd = path.join(os.tmpdir(), 'cdp-i-' + Date.now());
  const chrome = spawn('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', [
    '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
    '--disable-blink-features=AutomationControlled', '--window-size=1366,900', '--lang=en-US',
    '--user-data-dir=' + udd, '--proxy-server=http://127.0.0.1:' + LOCAL_PORT,
    '--remote-debugging-port=' + CDP_PORT, TARGET
  ], { stdio: 'ignore' });

  const ver = await getJson('http://127.0.0.1:' + CDP_PORT + '/json/version', 40);
  if (!ver) { console.log(JSON.stringify({ ok: false, err: 'cdp not ready' })); chrome.kill(); relay.close(); return; }

  const ws = new WebSocket(ver.webSocketDebuggerUrl);
  let id = 0; const pending = new Map();
  ws.addEventListener('message', ev => {
    try { const m = JSON.parse(ev.data); if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); } } catch (e) {}
  });
  await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', rej); });

  function send(method, params) {
    return new Promise(resolve => { const mid = ++id; pending.set(mid, resolve); ws.send(JSON.stringify({ id: mid, method, params: params || {} })); });
  }

  await sleep(parseInt(process.env.WAIT || '13000', 10));

  const targets = await send('Target.getTargets');
  let sessionId = null;
  if (targets && targets.result) {
    const pg = targets.result.targetInfos.find(t => t.type === 'page');
    if (pg) { const att = await send('Target.attachToTarget', { targetId: pg.targetId, flatten: true }); if (att && att.result) sessionId = att.result.sessionId; }
  }

  const expr = `(function(){
    var out = {};
    out.href = location.href;
    out.title = document.title;
    out.htmlLen = document.documentElement.outerHTML.length;
    out.iframes = Array.prototype.map.call(document.querySelectorAll('iframe'), function(f){ return f.src || ''; }).filter(function(s){ return s.indexOf('captcha') >= 0 || s.indexOf('hcaptcha') >= 0; });
    out.names = Array.prototype.map.call(document.querySelectorAll('input,textarea'), function(e){ return e.name; });
    out.ids = Array.prototype.map.call(document.querySelectorAll('input,textarea'), function(e){ return e.id; });
    out.hcapEnabled = !!window.hCaptchaEnabled;
    out.widgets = document.querySelectorAll('.captcha').length;
    return JSON.stringify(out);
  })()`;

  const r = await new Promise(resolve => {
    const mid = Math.floor(Math.random() * 1e9);
    const handler = ev => {
      try {
        const m = JSON.parse(ev.data);
        if (m.id === mid) { ws.removeEventListener('message', handler); resolve(m.result && m.result.result ? m.result.result.value : null); }
      } catch (e) {}
    };
    ws.addEventListener('message', handler);
    ws.send(JSON.stringify({ id: mid, method: 'Runtime.evaluate', params: { expression: expr, returnByValue: true }, sessionId }));
    setTimeout(() => resolve(null), 10000);
  });

  console.log(String(r));
  try { ws.close(); } catch (e) {}
  try { chrome.kill(); } catch (e) {}
  try { relay.close(); } catch (e) {}
  setTimeout(() => process.exit(0), 1200);
})();
