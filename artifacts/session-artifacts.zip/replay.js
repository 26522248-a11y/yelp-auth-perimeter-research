const http = require('http');
const net = require('net');
const fs = require('fs');
const { spawn } = require('child_process');
const os = require('os');
const path = require('path');

const PH = 'pr.oxylabs.io', PP = 7777;
const PU = process.env.PXUSER || 'customer-mobile_d2e4fc34-cc-us-sessid-hf03-sesstime-30';
const PW = process.env.PXPASS || '7E6Ci42a6C=8';
const AUTH = 'Basic ' + Buffer.from(PU + ':' + PW).toString('base64');
const LP = 8905, CP = 9227;

const relay = http.createServer((req, res) => {
  try {
    const u = new URL(req.url);
    const pr = http.request({ host: u.hostname, port: u.port || 80, method: req.method, path: u.pathname + u.search, headers: Object.assign({}, req.headers, { host: u.host }) }, r2 => { res.writeHead(r2.statusCode, r2.headers); r2.pipe(res); });
    pr.on('error', () => res.destroy()); req.pipe(pr);
  } catch (e) { res.destroy(); }
});
relay.on('connect', (req, cs, head) => {
  const s = net.connect(PP, PH, () => s.write('CONNECT ' + req.url + ' HTTP/1.1\r\nHost: ' + req.url + '\r\nProxy-Authorization: ' + AUTH + '\r\n\r\n'));
  let buf = Buffer.alloc(0);
  function onData(d) {
    buf = Buffer.concat([buf, d]);
    const i = buf.indexOf('\r\n\r\n'); if (i < 0) return;
    s.removeListener('data', onData);
    const rest = buf.slice(i + 4);
    const m = buf.slice(0, i).toString().match(/^HTTP\/1\.[01]\s+(\d+)/);
    if (!m || parseInt(m[1], 10) !== 200) { try { cs.end('HTTP/1.1 502 Bad Gateway\r\n\r\n'); } catch (e) {} s.destroy(); return; }
    cs.write('HTTP/1.1 200 Connection Established\r\n\r\n');
    if (rest.length) cs.write(rest);
    s.pipe(cs); cs.pipe(s);
    if (head && head.length) s.write(head);
    s.on('error', () => cs.destroy()); cs.on('error', () => s.destroy());
  }
  s.on('data', onData);
  s.on('error', () => { try { cs.end('HTTP/1.1 502 Bad Gateway\r\n\r\n'); } catch (e) {} });
});

const sleep = ms => new Promise(r => setTimeout(r, ms));
async function j(u, n) { for (let i = 0; i < n; i++) { try { const r = await fetch(u); return await r.json(); } catch (e) { await sleep(500); } } return null; }

(async () => {
  await new Promise(r => relay.listen(LP, '127.0.0.1', r));
  const udd = path.join(os.tmpdir(), 'cdp-rp-' + Date.now());
  const chrome = spawn('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', [
    '--no-first-run', '--no-default-browser-check',
    '--disable-blink-features=AutomationControlled',
    '--window-size=1366,950', '--lang=en-US',
    '--user-data-dir=' + udd,
    '--proxy-server=http://127.0.0.1:' + LP,
    '--remote-debugging-port=' + CP,
    'https://www.yelp.com/login'
  ], { stdio: 'ignore' });

  const ver = await j('http://127.0.0.1:' + CP + '/json/version', 40);
  if (!ver) { console.log('{"ok":false,"err":"cdp"}'); chrome.kill(); relay.close(); return; }
  const ws = new WebSocket(ver.webSocketDebuggerUrl);
  let id = 0; const pend = new Map();
  ws.addEventListener('message', ev => { try { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } } catch (e) {} });
  await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', rej); });
  const send = (m, p) => new Promise(resolve => { const mid = ++id; pend.set(mid, resolve); ws.send(JSON.stringify({ id: mid, method: m, params: p || {} })); });

  await sleep(9000);
  const t = await send('Target.getTargets');
  let sid = null;
  if (t && t.result) { const pg = t.result.targetInfos.find(x => x.type === 'page'); if (pg) { const a = await send('Target.attachToTarget', { targetId: pg.targetId, flatten: true }); if (a && a.result) sid = a.result.sessionId; } }
  const ev = e => new Promise(resolve => {
    const mid = Math.floor(Math.random() * 1e9);
    const h = x => { try { const m = JSON.parse(x.data); if (m.id === mid) { ws.removeEventListener('message', h); resolve(m.result && m.result.result ? m.result.result.value : null); } } catch (err) {} };
    ws.addEventListener('message', h);
    ws.send(JSON.stringify({ id: mid, method: 'Runtime.evaluate', params: { expression: e, returnByValue: true, awaitPromise: true }, sessionId: sid }));
    setTimeout(() => resolve(null), 40000);
  });

  console.log('BASE ' + await ev(`JSON.stringify({href:location.href,title:document.title,len:document.documentElement.outerHTML.length})`));

  await ev(`location.href='https://www.yelp.com/login/'`);
  await sleep(4000);
  console.log('PAGE ' + await ev(`JSON.stringify({href:location.href,form:!!document.getElementById('ajax-login')})`));

  // real form submit (auto-invisible captcha)
  await ev(`(function(){var f=document.getElementById('ajax-login');var e=f.querySelector('input[name=email]'),p=f.querySelector('input[name=password]');e.value='qa.probe7.5657@example.com';p.value='WrongPass999!';e.dispatchEvent(new Event('input',{bubbles:true}));p.dispatchEvent(new Event('input',{bubbles:true}));f.querySelector('button[type=submit]').click();return 1;})()`);
  await sleep(12000);

  const tok = await ev(`(document.querySelector('[name="h-captcha-response"]')||{}).value||''`);
  const alert1 = await ev(`(document.querySelector('.alert-message')||{}).textContent||''`);
  console.log('TOKEN_LEN ' + (tok ? tok.length : 0));
  console.log('TOKEN_HEAD ' + (tok ? tok.slice(0, 40) : ''));
  console.log('ALERT1 ' + alert1);

  // replay test: same token, fresh csrftok each attempt, 3 wrong passwords
  const script = `(async () => {
    const token = ${JSON.stringify(tok)};
    const out = [];
    for (const pw of ['WrongA111!','WrongB222!','WrongC333!']) {
      const html = await (await fetch('/login/', {credentials:'include'})).text();
      const m = html.match(/id="ajax-login"[\\s\\S]{0,2000}?name="csrftok"[^>]*value="([a-f0-9]+)"/);
      const ct = m ? m[1] : '';
      const body = new URLSearchParams({csrftok: ct, email:'qa.probe7.5657@example.com', password: pw});
      body.set('h-captcha-response', token);
      body.set('g-recaptcha-response', token);
      const r = await fetch('/login/', {method:'POST', credentials:'include', headers:{'Content-Type':'application/x-www-form-urlencoded','X-Requested-With':'XMLHttpRequest'}, body});
      const txt = await r.text();
      const am = txt.match(/<p class="alert-message">\\s*([\\s\\S]*?)\\s*<\\/p>/);
      out.push({pw, status:r.status, csrf: ct ? ct.slice(0,8) : 'none', alert: am ? am[1].replace(/\\s+/g,' ').trim() : ('len='+txt.length)});
    }
    return JSON.stringify(out);
  })()`;

  console.log('REPLAY ' + await ev(script));

  try { ws.close(); } catch (e) {}
  try { chrome.kill(); } catch (e) {}
  try { relay.close(); } catch (e) {}
  setTimeout(() => process.exit(0), 1000);
})();
