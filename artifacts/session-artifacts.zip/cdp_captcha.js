const http = require('http');
const net = require('net');
const { spawn } = require('child_process');
const os = require('os');
const path = require('path');

const PROXY_HOST = 'pr.oxylabs.io';
const PROXY_PORT = 7777;
const PROXY_USER = process.env.PXUSER || 'customer-mobile_d2e4fc34-cc-us-sessid-insp2-sesstime-20';
const PROXY_PASS = process.env.PXPASS || '7E6Ci42a6C=8';
const AUTH = 'Basic ' + Buffer.from(PROXY_USER + ':' + PROXY_PASS).toString('base64');
const LOCAL_PORT = 8902;
const CDP_PORT = 9224;

const relay = http.createServer((req, res) => {
  try {
    const u = new URL(req.url);
    const pr = http.request({ host: u.hostname, port: u.port || 80, method: req.method, path: u.pathname + u.search, headers: Object.assign({}, req.headers, { host: u.host }) }, presp => {
      res.writeHead(presp.statusCode, presp.headers); presp.pipe(res);
    });
    pr.on('error', () => res.destroy()); req.pipe(pr);
  } catch (e) { res.destroy(); }
});
relay.on('connect', (req, cs, head) => {
  const s = net.connect(PROXY_PORT, PROXY_HOST, () => {
    s.write('CONNECT ' + req.url + ' HTTP/1.1\r\nHost: ' + req.url + '\r\nProxy-Authorization: ' + AUTH + '\r\n\r\n');
  });
  let buf = Buffer.alloc(0);
  function onData(d) {
    buf = Buffer.concat([buf, d]);
    const idx = buf.indexOf('\r\n\r\n');
    if (idx === -1) return;
    s.removeListener('data', onData);
    const rest = buf.slice(idx + 4);
    const m = buf.slice(0, idx).toString().match(/^HTTP\/1\.[01]\s+(\d+)/);
    if (!m || parseInt(m[1], 10) !== 200) { try { cs.end('HTTP/1.1 502 Bad Gateway\r\n\r\n'); } catch (e) {} s.destroy(); return; }
    cs.write('HTTP/1.1 200 Connection Established\r\n\r\n');
    if (rest.length) cs.write(rest);
    s.pipe(cs); cs.pipe(s);
    if (head && head.length) s.write(head);
    s.on('error', () => cs.destroy()); cs.on('error', () => s.destroy());
  }
  s.on('data', onData);
  s.on('error', () => { try { cs.end('HTTP/1.1 502 Bad Gateway\r\n\r\n'); } catch (e) {} });
});

const sleep = ms => new Promise(r => setTimeout(r, ms));
async function getJson(url, tries) { for (let i = 0; i < tries; i++) { try { const r = await fetch(url); return await r.json(); } catch (e) { await sleep(500); } } return null; }

(async () => {
  await new Promise(r => relay.listen(LOCAL_PORT, '127.0.0.1', r));
  const udd = path.join(os.tmpdir(), 'cdp-c-' + Date.now());
  const chrome = spawn('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', [
    '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
    '--disable-blink-features=AutomationControlled', '--window-size=1366,900', '--lang=en-US',
    '--user-data-dir=' + udd, '--proxy-server=http://127.0.0.1:' + LOCAL_PORT,
    '--remote-debugging-port=' + CDP_PORT, 'https://www.yelp.com/login/'
  ], { stdio: 'ignore' });

  const ver = await getJson('http://127.0.0.1:' + CDP_PORT + '/json/version', 40);
  if (!ver) { console.log('{"ok":false,"err":"cdp"}'); chrome.kill(); relay.close(); return; }
  const ws = new WebSocket(ver.webSocketDebuggerUrl);
  let id = 0; const pend = new Map();
  ws.addEventListener('message', ev => { try { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } } catch (e) {} });
  await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', rej); });
  function send(method, params) { return new Promise(resolve => { const mid = ++id; pend.set(mid, resolve); ws.send(JSON.stringify({ id: mid, method, params: params || {} })); }); }

  await sleep(9000);
  const t = await send('Target.getTargets');
  let sid = null;
  if (t && t.result) { const pg = t.result.targetInfos.find(x => x.type === 'page'); if (pg) { const a = await send('Target.attachToTarget', { targetId: pg.targetId, flatten: true }); if (a && a.result) sid = a.result.sessionId; } }

  function evalExpr(expr) {
    return new Promise(resolve => {
      const mid = Math.floor(Math.random() * 1e9);
      const h = ev => { try { const m = JSON.parse(ev.data); if (m.id === mid) { ws.removeEventListener('message', h); resolve(m.result && m.result.result ? m.result.result.value : null); } } catch (e) {} };
      ws.addEventListener('message', h);
      ws.send(JSON.stringify({ id: mid, method: 'Runtime.evaluate', params: { expression: expr, returnByValue: true, awaitPromise: true }, sessionId: sid }));
      setTimeout(() => resolve(null), 12000);
    });
  }

  const before = await evalExpr(`JSON.stringify({hov: !!window.hcaptcha, hcapKeys: Object.keys(window).filter(k=>/hcap/i.test(k)), cfg: (window.yConfig||{}).hcaptchaSitekey, cfg2: (window.yConfig||{}).visibleHcaptchaSitekey})`);
  console.log('BEFORE ' + before);

  await evalExpr(`(function(){ var f=document.getElementById('ajax-login'); var e=f&&f.querySelector('input[name=email]'); var p=f&&f.querySelector('input[name=password]'); if(e) e.value='qa.probe7.5657@example.com'; if(p) p.value='WrongPass999!'; var b=f&&f.querySelector('button[type=submit]'); if(b) b.click(); return 'clicked'; })()`);
  await sleep(7000);

  const after = await evalExpr(`JSON.stringify({
    ifr: Array.prototype.map.call(document.querySelectorAll('iframe'), function(f){return f.src||''}).filter(function(s){return /hcaptcha|captcha/i.test(s)}),
    names: Array.prototype.map.call(document.querySelectorAll('textarea,input'), function(e){return e.name}).filter(function(n){return /captcha/i.test(n)}),
    div: (function(){var d=document.querySelector('.login-captcha'); return d? d.innerHTML.slice(0,300):'none'})(),
    hov: !!window.hcaptcha
  })`);
  console.log('AFTER ' + after);

  try { ws.close(); } catch (e) {}
  try { chrome.kill(); } catch (e) {}
  try { relay.close(); } catch (e) {}
  setTimeout(() => process.exit(0), 1000);
})();
